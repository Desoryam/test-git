#include <iostream>
#include <fstream>
using namespace std;

class Student {
    int roll_no, year, total_marks;
    char name[20];
    char Class[10];

public:
    void input();
    void display();
};

void Student::input() {
    cout << "Enter your details\n";
    cout << "Name: ";
    cin >> name;
    cout << "Roll number: ";
    cin >> roll_no;
    cout << "Class: ";
    cin >> Class;
    cout << "Year: ";
    cin >> year;
    cout << "Total marks obtained: ";
    cin >> total_marks;
}

void Student::display() {
    cout << "\nRoll No: " << roll_no;
    cout << "\nName: " << name;
    cout << "\nClass: " << Class;
    cout << "\nYear: " << year;
    cout << "\nMarks: " << total_marks << endl;
}

int main() {
    Student s;
    ofstream fout;
    ifstream fin;

    fout.open("student.dat", ios::binary);
    for (int i = 0; i < 5; i++) {
        cout << "\nEnter details of student " << i + 1 << ":\n";
        s.input();
        fout.write((char*)&s, sizeof(s));
    }
    fout.close();

    fin.open("student.dat", ios::binary);
    cout << "\n--- Student Records ---\n";

    while (fin.read((char*)&s, sizeof(s))) {
        s.display();
    }

    fin.close();
    return 0;
}
