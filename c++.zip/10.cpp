#include <iostream>
#include <cmath>
using namespace std;

class Triangle {
private:
    float a, b, c;

public:
    void getSides() {
        cout << "Enter three sides: ";
        cin >> a >> b >> c;

        if (a <= 0 || b <= 0 || c <= 0)
            throw "Sides must be greater than 0!";

        if ((a + b <= c) || (a + c <= b) || (b + c <= a))
            throw "Invalid triangle (Triangle inequality rule failed)!";
    }

    float area(float base, float height) {
        return 0.5 * base * height;
    }

    float area() {
        float s = (a + b + c) / 2;
        return sqrt(s * (s - a) * (s - b) * (s - c));
    }

    void display() {
        cout << "Sides: " << a << ", " << b << ", " << c << endl;
    }
};

int main() {
    Triangle t;
    int choice;

    try {
        t.getSides();
        t.display();

        cout << "\n1. Area (Right-angled)\n";
        cout << "2. Area (General - Heron's formula)\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            float base, height;
            cout << "Enter base and height: ";
            cin >> base >> height;

            cout << "Area = " << t.area(base, height) << endl;
        }
        else if (choice == 2) {
            cout << "Area = " << t.area() << endl;
        }
        else {
            cout << "Invalid choice!";
        }
    }
    catch (const char* msg) {
        cout << "Error: " << msg << endl;
    }

    return 0;
}
