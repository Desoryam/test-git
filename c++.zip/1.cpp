#include <iostream>
using namespace std;

double seq(int n){

  double pow;
  double sum=0.0;
  for (int i = 1; i <= n; i++){
    pow = i*i;
    double term= 1.0/pow;
    if (i%2 == 0){
      sum = sum - term;
    }
    else{
      sum = sum + term;
    }
  
  
  }
  return sum;
}




int main(){
  
  cout<<"ENTER THE VALUE ON n : ";
  int n;
  cin>>n;
  cout<< "\nthe sum of sequen with "<<n<<" value is :"<<seq(n);
  return 0;
  
}


