#include <iostream>
using namespace std;

int main()
{
    int a[50], b[50], c[100];
    int n1, n2;

    cout << "Enter number of elements in first array: ";
    cin >> n1;

    cout << "Enter elements of first array (sorted): ";
    for(int i = 0; i < n1; i++)
        cin >> a[i];

    cout << "Enter number of elements in second array: ";
    cin >> n2;

    cout << "Enter elements of second array (sorted): ";
    for(int i = 0; i < n2; i++)
        cin >> b[i];

    int i = 0, j = 0, k = 0;

    // Merge arrays
    while(i < n1 && j < n2)
    {
        if(a[i] < b[j])
        {
            c[k] = a[i];
            i++;
        }
        else
        {
            c[k] = b[j];
            j++;
        }
        k++;
    }

    // Copy remaining elements
    while(i < n1)
    {
        c[k] = a[i];
        i++;
        k++;
    }

    while(j < n2)
    {
        c[k] = b[j];
        j++;
        k++;
    }

    cout << "Merged array: ";
    for(int x = 0; x < k; x++)
        cout << c[x] << " ";

    return 0;
}
