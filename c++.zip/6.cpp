#include <iostream>
using namespace std;

int binarySearchRecursive(int arr[], int left, int right, int key) {
    if (left <= right) {
        int mid = (left + right) / 2;

        if (arr[mid] == key)
            return mid;
        else if (arr[mid] > key)
            return binarySearchRecursive(arr, left, mid - 1, key);
        else
            return binarySearchRecursive(arr, mid + 1, right, key);
    }
    return -1;
}

int binarySearchIterative(int arr[], int n, int key) {
    int left = 0, right = n - 1;

    while (left <= right) {
        int mid = (left + right) / 2;

        if (arr[mid] == key)
            return mid;
        else if (arr[mid] > key)
            right = mid - 1;
        else
            left = mid + 1;
    }
    return -1;
}

int main() {
    int n, key;

    cout << "Enter number of elements: ";
    cin >> n;

    int* arr = new int[n];

    cout << "Enter sorted elements:\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    cout << "Enter element to search: ";
    cin >> key;

    int result1 = binarySearchRecursive(arr, 0, n - 1, key);

    if (result1 != -1)
        cout << "\nRecursive: Element found at index " << result1;
    else
        cout << "\nRecursive: Element not found";

    int result2 = binarySearchIterative(arr, n, key);

    if (result2 != -1)
        cout << "\nIterative: Element found at index " << result2;
    else
        cout << "\nIterative: Element not found";

    delete[] arr;
    return 0;
}
