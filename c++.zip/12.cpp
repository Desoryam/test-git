#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream fin("input.txt");
    ofstream fout("output.txt");

    if (!fin) {
        cout << "Error opening input file!";
        return 1;
    }

    char ch;
    while (fin.get(ch)) {
        if (ch != ' ' && ch != '\n' && ch != '\t') {
            fout << ch;
        }
    }

    cout << "File copied without whitespaces.\n";

    fin.close();
    fout.close();

    return 0;
}
