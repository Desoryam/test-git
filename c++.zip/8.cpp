#include <iostream>
using namespace std;

class Matrix {
private:
    int rows, cols;
    int mat[10][10];

public:
    void getMatrix() {
        cout << "Enter rows and columns: ";
        cin >> rows >> cols;

        cout << "Enter elements:\n";
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                cin >> mat[i][j];
            }
        }
    }

    void display() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                cout << mat[i][j] << " ";
            }
            cout << endl;
        }
    }

    Matrix add(Matrix m) {
        if (rows != m.rows || cols != m.cols)
            throw "Addition not possible!";

        Matrix result;
        result.rows = rows;
        result.cols = cols;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.mat[i][j] = mat[i][j] + m.mat[i][j];
            }
        }
        return result;
    }

    Matrix multiply(Matrix m) {
        if (cols != m.rows)
            throw "Multiplication not possible!";

        Matrix result;
        result.rows = rows;
        result.cols = m.cols;

        for (int i = 0; i < result.rows; i++) {
            for (int j = 0; j < result.cols; j++) {
                result.mat[i][j] = 0;
                for (int k = 0; k < cols; k++) {
                    result.mat[i][j] += mat[i][k] * m.mat[k][j];
                }
            }
        }
        return result;
    }

    Matrix transpose() {
        Matrix result;
        result.rows = cols;
        result.cols = rows;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.mat[j][i] = mat[i][j];
            }
        }
        return result;
    }
};

int main() {
    Matrix m1, m2, res;
    int choice;

    do {
        cout << "\n--- Matrix Operations ---\n";
        cout << "1. Sum\n2. Product\n3. Transpose\n4. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        try {
            switch (choice) {
                case 1:
                    cout << "\nEnter Matrix 1:\n";
                    m1.getMatrix();
                    cout << "Enter Matrix 2:\n";
                    m2.getMatrix();

                    res = m1.add(m2);
                    cout << "\nResult (Sum):\n";
                    res.display();
                    break;

                case 2:
                    cout << "\nEnter Matrix 1:\n";
                    m1.getMatrix();
                    cout << "Enter Matrix 2:\n";
                    m2.getMatrix();

                    res = m1.multiply(m2);
                    cout << "\nResult (Product):\n";
                    res.display();
                    break;

                case 3:
                    cout << "\nEnter Matrix:\n";
                    m1.getMatrix();

                    res = m1.transpose();
                    cout << "\nTranspose:\n";
                    res.display();
                    break;

                case 4:
                    cout << "Exiting...\n";
                    break;

                default:
                    cout << "Invalid choice!\n";
            }
        } catch (const char* msg) {
            cout << "Error: " << msg << endl;
        }

    } while (choice != 4);

    return 0;
}
