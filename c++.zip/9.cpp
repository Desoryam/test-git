#include <iostream>
#include <string>
using namespace std;

class Person {
protected:
    string name;

public:
    void getName() {
        cout << "Enter name: ";
        cin >> name;
    }

    virtual void display() {
        cout << "Name: " << name << endl;
    }
};

class Student : public Person {
private:
    string course;
    int marks;
    int year;

public:
    void getStudentData() {
        getName();
        cout << "Enter course: ";
        cin >> course;
        cout << "Enter marks: ";
        cin >> marks;
        cout << "Enter year: ";
        cin >> year;
    }

    void display() {
        cout << "Student Details:\n";
        cout << "Name: " << name << endl;
        cout << "Course: " << course << endl;
        cout << "Marks: " << marks << endl;
        cout << "Year: " << year << endl;
    }
};

class Employee : public Person {
private:
    string department;
    float salary;

public:
    void getEmployeeData() {
        getName();
        cout << "Enter department: ";
        cin >> department;
        cout << "Enter salary: ";
        cin >> salary;
    }

    void display() {
        cout << "Employee Details:\n";
        cout << "Name: " << name << endl;
        cout << "Department: " << department << endl;
        cout << "Salary: " << salary << endl;
    }
};

int main() {
    Person* p;

    Student s;
    Employee e;

    cout << "\n--- Enter Student Data ---\n";
    s.getStudentData();

    cout << "\n--- Enter Employee Data ---\n";
    e.getEmployeeData();

    p = &s;
    cout << "\n--- Display Student ---\n";
    p->display();

    p = &e;
    cout << "\n--- Display Employee ---\n";
    p->display();

    return 0;
}
