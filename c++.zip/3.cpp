#include <iostream>
#include <cstring>
using namespace std;

int main(int argc, char *argv[])
{
    int count[26] = {0};

    // Loop through command line arguments
    for(int i = 1; i < argc; i++)
    {
        for(int j = 0; argv[i][j] != '\0'; j++)
        {
            char ch = argv[i][j];

            // Convert uppercase to lowercase
            if(ch >= 'A' && ch <= 'Z')
                ch = ch + 32;

            if(ch >= 'a' && ch <= 'z')
                count[ch - 'a']++;
        }
    }

    cout << "Alphabet\tOccurrences\n";

    for(int i = 0; i < 26; i++)
    {
        if(count[i] > 0)
            cout << char('a' + i) << "\t\t" << count[i] << endl;
    }

    return 0;
}
