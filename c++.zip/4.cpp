#include <iostream>
using namespace std;

void showAddress(char str[])
{
    for(int i = 0; str[i] != '\0'; i++)
        cout << str[i] << " -> " << (void*)&str[i] << endl;
}

void concatenate(char str1[], char str2[])
{
    int i=0, j=0;

    while(str1[i] != '\0')
        i++;

    while(str2[j] != '\0')
    {
        str1[i] = str2[j];
        i++;
        j++;
    }

    str1[i] = '\0';

    cout << "Concatenated string: " << str1 << endl;
}

void compare(char str1[], char str2[])
{
    int i = 0;

    while(str1[i] == str2[i] && str1[i] != '\0')
        i++;

    if(str1[i] == str2[i])
        cout << "Strings are equal\n";
    else
        cout << "Strings are not equal\n";
}

void length(char *str)
{
    int count = 0;

    while(*str != '\0')
    {
        count++;
        str++;
    }

    cout << "Length = " << count << endl;
}

void toUpper(char str[])
{
    for(int i = 0; str[i] != '\0'; i++)
    {
        if(str[i] >= 'a' && str[i] <= 'z')
            str[i] = str[i] - 32;
    }

    cout << "Uppercase string: " << str << endl;
}

void reverse(char str[])
{
    int len = 0;

    while(str[len] != '\0')
        len++;

    for(int i = len-1; i >= 0; i--)
        cout << str[i];

    cout << endl;
}

void insert(char str1[], char str2[], int pos)
{
    char result[200];
    int i=0, j=0, k=0;

    while(i < pos)
    {
        result[k++] = str1[i++];
    }

    while(str2[j] != '\0')
        result[k++] = str2[j++];

    while(str1[i] != '\0')
        result[k++] = str1[i++];

    result[k] = '\0';

    cout << "Result string: " << result << endl;
}

int main()
{
    char str1[100], str2[100];
    int choice, pos;

    cout << "Enter first string: ";
    cin >> str1;

    cout << "Enter second string: ";
    cin >> str2;

    do
    {
        cout << "\nMENU\n";
        cout << "1. Show address of each character\n";
        cout << "2. Concatenate strings\n";
        cout << "3. Compare strings\n";
        cout << "4. Length of string\n";
        cout << "5. Convert to uppercase\n";
        cout << "6. Reverse string\n";
        cout << "7. Insert string\n";
        cout << "8. Exit\n";

        cout << "Enter choice: ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                showAddress(str1);
                break;

            case 2:
                concatenate(str1, str2);
                break;

            case 3:
                compare(str1, str2);
                break;

            case 4:
                length(str1);
                break;

            case 5:
                toUpper(str1);
                break;

            case 6:
                reverse(str1);
                break;

            case 7:
                cout << "Enter position: ";
                cin >> pos;
                insert(str1, str2, pos);
                break;

            case 8:
                break;

            default:
                cout << "Invalid choice\n";
        }

    } while(choice != 8);

    return 0;
}
